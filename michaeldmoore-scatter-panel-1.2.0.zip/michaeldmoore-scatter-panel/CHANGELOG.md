# Change Log

All notable changes to this project will be documented in this file.

## v1.0.0

- Initial Release

## v1.1.0

- Updates, bug fixes, and enhancements.
- Support for more regression types, log scales and optional label naming based on table data.

## v1.2.0

- Add horizontal reference lines
- Support dot coloring override based on string field in data set.

![Scatter v1 2 0 features5](https://user-images.githubusercontent.com/3724718/203571154-711cfed5-02a8-488e-8267-0598d1f41417.png)


